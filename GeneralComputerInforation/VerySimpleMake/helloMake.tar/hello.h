#ifndef HELLO_H
#define HELLO_H

void print_hello();

#endif
